import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Profile')),
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          CircleAvatar(radius: 50,
            backgroundImage: AssetImage('assets/images/${image_files[-1]}')),
          SizedBox(height: 16),
          Text('User Name', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          Text('user@example.com', style: TextStyle(fontSize: 16)),
        ]),
      ),
    );
  }
}
