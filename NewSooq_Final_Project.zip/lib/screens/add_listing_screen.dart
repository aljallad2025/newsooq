import 'package:flutter/material.dart';

class AddListingScreen extends StatefulWidget {
  @override
  _AddListingScreenState createState() => _AddListingScreenState();
}

class _AddListingScreenState extends State<AddListingScreen> {
  final _formKey = GlobalKey<FormState>();
  String title = '', desc = '', price = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Add Listing')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(decoration: InputDecoration(labelText: 'Title'),
                onSaved: (val) => title = val!, validator: (val) => val!.isNotEmpty ? null : 'Required'),
              TextFormField(decoration: InputDecoration(labelText: 'Desc'),
                onSaved: (val) => desc = val!, validator: (val) => val!.isNotEmpty ? null : 'Required'),
              TextFormField(decoration: InputDecoration(labelText: 'Price'),
                keyboardType: TextInputType.number, onSaved: (val) => price = val!, validator: (val) => val!.isNotEmpty ? null : 'Required'),
              SizedBox(height: 20),
              ElevatedButton(child: Text('Submit'), onPressed: () {
                if (_formKey.currentState!.validate()) {
                  _formKey.currentState!.save();
                  Navigator.pop(context);
                }
              }),
            ],
          ),
        ),
      ),
    );
  }
}
