import 'package:flutter/material.dart';

class SearchResultsScreen extends StatelessWidget {
  final results = ['Result1', 'Result2', 'Result3'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Search Results')),
      body: ListView.builder(
        itemCount: results.length,
        itemBuilder: (c, i) => ListTile(
          leading: Icon(Icons.search), title: Text(results[i]),
        ),
      ),
    );
  }
}
