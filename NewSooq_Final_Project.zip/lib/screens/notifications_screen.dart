import 'package:flutter/material.dart';

class NotificationsScreen extends StatelessWidget {
  final notes = ['Welcome to NewSooq', 'Your listing sold!'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Notifications')),
      body: ListView.builder(
        itemCount: notes.length,
        itemBuilder: (c, i) => ListTile(title: Text(notes[i])),
      ),
    );
  }
}
