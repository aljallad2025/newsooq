import 'package:flutter/material.dart';

class MyListingsScreen extends StatelessWidget {
  final listings = [
${', '.join("{'title': '" + img.split('.')[0] + "', 'img': '" + img + "'}" for img in image_files[4:6])}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('My Listings')),
      body: ListView.builder(
        itemCount: listings.length,
        itemBuilder: (c, i) {
          final itm = listings[i];
          return ListTile(
            leading: Image.asset('assets/images/' + itm['img']!),
            title: Text(itm['title']!),
            trailing: Icon(Icons.edit),
            onTap: () => Navigator.pushNamed(context, '/details'),
          );
        },
      ),
    );
  }
}
