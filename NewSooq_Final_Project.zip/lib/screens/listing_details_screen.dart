import 'package:flutter/material.dart';

class ListingDetailsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Details')),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset('assets/images/${image_files[3]}', fit: BoxFit.cover),
            SizedBox(height: 16),
            Text('Item Title', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('Item description goes here.', style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
