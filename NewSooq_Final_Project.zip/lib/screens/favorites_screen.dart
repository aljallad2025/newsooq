import 'package:flutter/material.dart';

class FavoritesScreen extends StatelessWidget {
  final favs = [
${', '.join(f"'{img}'" for img in image_files[6:9])}
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Favorites')),
      body: GridView.builder(
        padding: EdgeInsets.all(8),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, childAspectRatio: 1, crossAxisSpacing: 8, mainAxisSpacing: 8),
        itemCount: favs.length,
        itemBuilder: (c, i) => GestureDetector(onTap: () => Navigator.pushNamed(context, '/details'),
            child: Image.asset('assets/images/' + favs[i], fit: BoxFit.cover)),
      ),
    );
  }
}
