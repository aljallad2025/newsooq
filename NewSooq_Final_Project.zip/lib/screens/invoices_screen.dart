import 'package:flutter/material.dart';

class InvoicesScreen extends StatelessWidget {
  final invs = [
{"id": "INV1", "amt": "100"},
{"id": "INV2", "amt": "200"},
{"id": "INV3", "amt": "300"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Invoices')),
      body: ListView.builder(
        itemCount: invs.length,
        itemBuilder: (c, i) {
          final inv = invs[i];
          return ListTile(
            leading: Icon(Icons.receipt),
            title: Text(inv['id']!),
            subtitle: Text('=\$' + inv['amt']!),
          );
        },
      ),
    );
  }
}
