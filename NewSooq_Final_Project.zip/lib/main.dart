import 'package:flutter/material.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'screens/home_screen.dart';
import 'screens/listing_details_screen.dart';
import 'screens/add_listing_screen.dart';
import 'screens/my_listings_screen.dart';
import 'screens/favorites_screen.dart';
import 'screens/invoices_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/notifications_screen.dart';
import 'screens/search_results_screen.dart';
import 'screens/map_screen.dart';

void main() {
  runApp(NewSooqApp());
}

class NewSooqApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NewSooq',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: '/splash',
      routes: {
        '/splash': (_) => SplashScreen(),
        '/login': (_) => LoginScreen(),
        '/signup': (_) => SignUpScreen(),
        '/home': (_) => HomeScreen(),
        '/details': (_) => ListingDetailsScreen(),
        '/add': (_) => AddListingScreen(),
        '/myListings': (_) => MyListingsScreen(),
        '/favorites': (_) => FavoritesScreen(),
        '/invoices': (_) => InvoicesScreen(),
        '/profile': (_) => ProfileScreen(),
        '/notifications': (_) => NotificationsScreen(),
        '/search': (_) => SearchResultsScreen(),
        '/map': (_) => MapScreen(),
      },
    );
  }
}
